def find(temp, check):
    print("S29->", end="")
    for item in temp:
        if item == check:
            print("S31->", end="")
            print("S29->", end="")
            return True
    print("S30->", end="")
    print("S29->", end="")
    return False


def condition(temp):
    print("S32->", end="")
    out = ""
    print("S33->", end="")
    for index in range(temp.index("("), len(temp)):
        out += temp[index]
        print("S34->", end="")
    print("S35->", end="")
    print("S32->", end="")
    return out.removesuffix(";")


if __name__ == '__main__':
    print("S0->", end="")
    outCode = ""
    labelName = "loop"
    labelID = 0
    prevCnt = 0
    keysMap = {}
    doID = 0
    print("S1->", end="")
    with open("in.txt", "r") as sppFile:
        print("S2->", end="")
        doWhileCode = sppFile.read().split("\n")
        print("S3->", end="")
        for string in doWhileCode:
            cnt = 0
            print("S4->", end="")
            for i in string.split("\t"):
                if i == "":
                    cnt += 1
                    print("S5->", end="")
            stroke = string.split(" ")
            print("S6->", end="")
            for word in stroke:
                tempWord = word.split("\t")
                print("S7->", end="")
                if print("S8->", end="") and find(tempWord, "do") and (stroke[-1] == "{" or string[-1] == "o"):
                    print("S8->", end="")
                    doID += 1
                    print("S9->", end="")
                    if cnt >= prevCnt:
                        labelID += 1
                        print("S10->", end="")
                        print("S11->", end="")
                        if find(keysMap, labelID):
                            print("S11->", end="")
                            import collections

                            [last] = collections.deque(keysMap, maxlen=1)
                            labelID = last + 1
                            print("S12->", end="")
                    else:
                        labelID -= 1
                        print("S13->", end="")
                    keysMap[labelID] = 1
                    prevCnt = cnt
                    print("S14->", end="")
                    for i in tempWord:
                        if i == "":
                            outCode += "\t"
                            print("S15->", end="")
                    outCode += labelName + str(labelID) + ":"
                    print("S16->", end="")
                elif print("S17->", end="") and find(tempWord, "while") and doID >= 1:
                    print("S17->", end="")
                    doID -= 1
                    print("S36->", end="")
                    print("S18->", end="")
                    condition(string)
                    print("S18->", end="")
                    outCode += "if" + condition(string) + "{\n"
                    print("S19->", end="")
                    for i in range(cnt + 1):
                        outCode += "\t"
                        print("S20->", end="")
                    if cnt > prevCnt:
                        labelID += 1
                        print("S21->", end="")
                    elif cnt < prevCnt:
                        labelID += 1
                        print("S22->", end="")
                        labelID -= 1
                    prevCnt = cnt
                    outCode += "goto " + labelName + str(labelID) + ";\n"
                    labelID += 1
                    print("S23->", end="")
                    for i in range(cnt):
                        outCode += "\t"
                        print("S24->", end="")
                    outCode += "}"
                    print("S25->", end="")
                    break
                else:
                    outCode += word + " "
                    print("S26->", end="")

            outCode += "\n"
            print("S27->", end="")
    with open("out.txt", "w+") as sppFile:
        sppFile.write(outCode)
        print("S28->", end="")
    print("S0", end="")
