import time

class MatrixInterpreter:

    count_a = 4
    count_x = 11
    yb = [] #массив, хранящий матрицы состояний у
    w = []
    u = []
    conditions = []   #массив, хранящий информацию о посещении каждого состояния

    # Конструктор класса. Инициализирует массивы yb, w, u и conditions
    def __init__(self, count_y, count_wu, rows_count):
        matrices = self.load_matrices("matrix.txt")

        # Заполнение массивов yb, w, u данными из матрицы
        for x in range(count_y):
            self.yb.append(matrices[x])

        for x in range(count_y, count_y + count_wu):
            self.w.append(matrices[x])

        for x in range(count_y + count_wu, count_y + count_wu * 2):
            self.u.append(matrices[x])

        # Заполнение массива conditions False до длины rows_count
        self.conditions = [False for i in range(rows_count)]

    # этот метод загружает матрицы из файла и возвращает их в виде списка списков строк
    def load_matrices(self, path):
        matrices = []

        with open(path) as reader:
            lines = reader.readlines()

            for l in lines:
                pointer = l.find("= ")
                if pointer != -1:
                    matrices.append([])
                    pointer += 2
                    cons = l[pointer:]

                    split_cons = cons.split(" ")
                    for x in range(len(split_cons)):
                        if x % 2 == 0:
                            expression = split_cons[x]
                            row = self.get_row(expression, self.count_a, self.count_x)
                            matrices[-1].append(row)

        return matrices

    #этот метод принимает строку-выражение, представляющую строку матрицы, и преобразует ее в строку символов (str). Это делается путем разбиения выражения на отдельные символы и последующего анализа каждого символа.
    # В результате получается строка символов, представляющая данную строку матрицы.
    def get_row(self, expression, count_a, count_x) -> str:
        row = list('-' * (count_a + count_x)) # создание массива из "-"

        bit = '1'
        num = ""
        index = 0
        is_last_digit = False

        # Обработка символов выражения
        for c in expression:
            is_last_digit, index, num, row, bit = self.update_character_of_expression(c,
                                                                                      is_last_digit,
                                                                                      index, num, row, bit)
        # Добавление недостающего бита в конец строки и возврат результата
        is_last_digit, index, num, row, bit = self.update_character_of_expression(' ',
                                                                                  is_last_digit, index, num, row, bit)

        return "".join(row)

    #этот метод принимает текущее состояние и входную последовательность xb и возвращает строку символов, представляющую текущее состояние s и вход.
    def get_row2(self, s, xb):
        row = format(s, "0" + str(len(self.w)) + "b")
        for x in range(1, len(xb)):
            temp = str(int(xb[x]))
            row += temp
        return row

    # это вспомогательный метод, используемый для обновления строки символов (row) на основе текущего символа (c), индекса (index) и значения бита (bit).
    def update_character_of_expression(self, c, is_last_digit, index, num, row, bit):
        if not c.isdigit() and is_last_digit:
            index += int(num) - 1
            num = ""
            row[index] = str(bit)
            bit = 1
            is_last_digit = False

        if c == '^':
            bit = '0'

        if c == 'a':
            index = 0

        if c == 'x':
            index = self.count_a

        if c.isdigit():
            num += c
            is_last_digit = True
        else:
            num = ""

        return is_last_digit, index, num, row, bit

    # Сравнение двух строк состояний
    @staticmethod
    def compare_rows(inp, comparator) -> bool:
        is_equal = True
        for x in range(len(inp)): #Если одна из строк матрицы равна строке состояния, в которой отсутствуют символы "-", вернуть True
            if inp[x] != comparator[x] and comparator[x] != '-':
                is_equal = False
                break
        return is_equal

    #это статический метод, который сравнивает строку символов с каждой строкой матрицы и возвращает True,
    #если он находит соответствие, и False в противном случае.
    @staticmethod
    def compare_row_with_matrix(inp, matrix):
        is_equal = False
        for x in range(len(matrix)):
            if MatrixInterpreter.compare_rows(inp, matrix[x]):
                is_equal = True
                break
        return is_equal

    #этот метод изменяет состояния системы A на основе полученной строки символов (row) и сохраненных матриц W и U.
    #Метод заменяет соответствующие биты в A на 1 или 0 в зависимости от совпадения с матрицами W и U.
    def change_a(self, a, row) -> str:
        for x in range(len(self.w)):
            if MatrixInterpreter.compare_row_with_matrix(row, self.w[x]):
                a[x] = '1'

            if MatrixInterpreter.compare_row_with_matrix(row, self.u[x]):
                a[x] = '0'
        return "".join(a)

    def get_y_str(self, iteration, row) -> str:

        result = "Состояния y(1..15): "

        if iteration == 0:
            result += "-   "
        else:
            found_y = False
            for x in range(len(self.yb)):
                if MatrixInterpreter.compare_row_with_matrix(row, self.yb[x]):
                    found_y = True
                    result += "y" + str(x + 1)
            if found_y:
                result += "   "
            else:
                result += "-   "

        # получение бинарных значений состояний y
        result += "Состояния бинарные y(1..15): "
        if iteration == 0:
            result += "0" * len(self.yb)
        else:
            bin_y = list("0" * len(self.yb))
            for x in range(len(self.yb)):
                bin_y[x] = '1' if MatrixInterpreter.compare_row_with_matrix(row, self.yb[x]) else '0'
            result += "".join(bin_y)

        return result

    #Метод для вывода текущего состояния автомата
    def print_state(self, s, row, iteration):
        print("Состояние: S" + str(s) + "   ", end="")
        print("Состояния a(1..4): " + format(s, '04b') + "   ", end="")

        print(self.get_y_str(iteration, row))

    #Метод для перехода на следующее состояние
    def next_step(self, s, xb):
        row = self.get_row2(s, xb)
        ss = list(format(s, "0" + str(len(self.w)) + "b"))

        return int(self.change_a(ss, row), 2)

    #этот метод запускает интерпретатор матриц.
    def start(self, xb):
        start = time.time()
        s = 0
        row = ""
        iteration = 0
        while not self.conditions[s]:
            self.conditions[s] = True
            self.print_state(s, row, iteration)
            row = self.get_row2(s, xb)
            s = self.next_step(s, xb)
            iteration += 1

        self.print_state(s, row, iteration)
        row = self.get_row2(s, xb)


        end = time.time()

        elapsed_time = end - start
        elapsed_time_ms = elapsed_time * 1000.0

        if s == 0:
            print("Алгортим завершил работу за ", end="")
        else:
            print("Алгоритм зациклился на состоянии " + str(s) + " за ", end="")


        print(str(elapsed_time_ms) + " миллисекунд.")